﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DIVISION2_RECON_API
{
    public interface IProcessService
    {
        IEnumerable<ProcessModel> GetAllItems(string customerName, string sensor);
        ProcessModel GetById(int id);
    }
}
