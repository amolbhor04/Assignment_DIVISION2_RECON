﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace DIVISION2_RECON_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProcessController : ControllerBase
    {
        private readonly IProcessService _service;
        public ProcessController(IProcessService service)
        {
            _service = service;
        }

        // GET api/process/customerName/sensor/
        [HttpGet("{customerName}/{sensor}")]
        public ActionResult<string> Get(string customerName, string sensor)
        {
            var resData = _service.GetAllItems(customerName, sensor);
            var data = JsonConvert.SerializeObject(resData);
            //return new string[] { data };
            return data;
        }

        // GET api/process/5
        [HttpGet("detail/{id}")]
        public ActionResult<string> GetProcessDetails(int id)
        {
            var resData = _service.GetById(id);
            return JsonConvert.SerializeObject(resData);
        }

    }
}
