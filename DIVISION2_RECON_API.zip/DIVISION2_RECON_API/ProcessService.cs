﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace DIVISION2_RECON_API
{
    public class ProcessService : IProcessService
    {
        public IEnumerable<ProcessModel> GetAllItems(string customerName, string sensor)
        {
            using (StreamReader r = new StreamReader("../DIVISION2_RECON_API/data/table1.json"))
            {
                string json = r.ReadToEnd();
                List<ProcessModel> processes = JsonConvert.DeserializeObject<List<ProcessModel>>(json);

                if (!string.IsNullOrEmpty(customerName) || !string.IsNullOrEmpty(sensor))
                {
                    processes = processes.Where(x => x.CustomerName.ToLower().Contains(customerName.ToLower()) ||
                                                        x.SensorData.ToLower().Contains(sensor.ToLower())).ToList();
                }

                return processes;
            }
        }
        public ProcessModel GetById(int id)
        {
            using (StreamReader r = new StreamReader("../DIVISION2_RECON_API/data/table1.json"))
            {
                string json = r.ReadToEnd();
                List<ProcessModel> processes = JsonConvert.DeserializeObject<List<ProcessModel>>(json);
                var data = processes.FirstOrDefault(x => x.CustomerId == id);
                return data;
            }
        }
    }
}
