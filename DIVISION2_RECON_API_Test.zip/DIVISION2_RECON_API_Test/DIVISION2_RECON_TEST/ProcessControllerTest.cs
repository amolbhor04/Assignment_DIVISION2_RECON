using DIVISION2_RECON_API;
using DIVISION2_RECON_API.Controllers;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace DIVISION2_RECON_TEST
{
    public class ProcessControllerTest
    {
        private readonly ProcessController _controller;
        private readonly IProcessService _service;

        public ProcessControllerTest()
        {
            _service = new ProcessServiceFake();
            _controller = new ProcessController(_service);
        }

        [Fact]
        public void Get_WhenCalled_ReturnsOkResult()
        {
            // Act
            var result = _controller.GetProcessDetails(3123);
            var okResult = JsonConvert.DeserializeObject<ProcessModel>(result.Value);
            // Assert
            Assert.IsType<ProcessModel>(okResult);
        }
        [Fact]
        public void Get_WhenCalled_ReturnsAllItems()
        {
            // Act
            var result = _controller.Get(_service.GetById(3123).CustomerName, _service.GetById(1).SensorData);
            var okResult = JsonConvert.DeserializeObject<List<ProcessModel>>(result.Value);
            // Assert
            var items = Assert.IsType<List<ProcessModel>>(okResult);
            Assert.Equal(3, items.Count);
        }


        [Fact]
        public void GetById_UnknownIDPassed_ReturnsNotFoundResult()
        {
            // Act
            var notFoundResult = _controller.GetProcessDetails(355743);
            // Assert
            Assert.IsType<NotFoundResult>(notFoundResult);
        }
        [Fact]
        public void GetById_ExistingIDPassed_ReturnsOkResult()
        {
            // Act
            var okResult = _controller.GetProcessDetails(3123);
            // Assert
            Assert.IsType<ProcessModel>(okResult);
        }
        [Fact]
        public void GetById_ExistingIDPassed_ReturnsRightItem()
        {
            // Act
            var data = _controller.GetProcessDetails(3123);
            var okResult = JsonConvert.DeserializeObject<ProcessModel>(data.Value);
            // Assert
            Assert.IsType<ProcessModel>(okResult);

            Assert.Equal(3123, okResult.CustomerId);
        }
    }
}
