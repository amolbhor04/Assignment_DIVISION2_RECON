﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DIVISION2_RECON_API
{
    public class ProcessModel
    {
        //Customer Id: unique identifier for each customer
        public int CustomerId { get; set; }

        //Customer Name: the name of the customer.This is usually the hospital name.
        public string CustomerName { get; set; }

        //Machine Nr: machine identifier for the customer
        public string MachineNr { get; set; }

        //Machine Id: a unique machine number per customer
        public int MachineId { get; set; }

        //MachineTypeSerial: type of machine and the corresponding serial number
        public string MachineTypeSerial { get; set; }

        //Process: the executed process name
        public string Process { get; set; }

        //ProcessTime: the start and the end date and time of the executed process
        public string ProcessTime { get; set; }

        //SensorData: the available data for the sensors
        public string SensorData { get; set; }

        //OnlineFrom: the date and time from which the machine is online
        public DateTime OnlineFrom { get; set; }
    }
}
